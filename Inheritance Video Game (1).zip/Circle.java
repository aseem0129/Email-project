import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
public class Circle extends Shape {
    private int radius;
    public Circle(int x, int y, int radius)
    {
        super(x,y);
        this.radius = radius;
    }

    double getRadius()
    {
        return radius;
    }

    void setRadius(int rad)
    {
        this.radius = rad;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g.setColor(Color.red);
        g2d.drawOval(getX(), getY(), radius, radius);
    }
}